-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: ecommerce_db
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add customers',7,'add_customers'),(26,'Can change customers',7,'change_customers'),(27,'Can delete customers',7,'delete_customers'),(28,'Can view customers',7,'view_customers'),(29,'Can add products',8,'add_products'),(30,'Can change products',8,'change_products'),(31,'Can delete products',8,'delete_products'),(32,'Can view products',8,'view_products'),(33,'Can add shopkeepers',9,'add_shopkeepers'),(34,'Can change shopkeepers',9,'change_shopkeepers'),(35,'Can delete shopkeepers',9,'delete_shopkeepers'),(36,'Can view shopkeepers',9,'view_shopkeepers'),(37,'Can add custom session',10,'add_customsession'),(38,'Can change custom session',10,'change_customsession'),(39,'Can delete custom session',10,'delete_customsession'),(40,'Can view custom session',10,'view_customsession'),(41,'Can add orders',11,'add_orders'),(42,'Can change orders',11,'change_orders'),(43,'Can delete orders',11,'delete_orders'),(44,'Can view orders',11,'view_orders');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$1000000$LVA7AJDe9iAvE2moR1oIEy$Hzf0owSuRnEs/aUs8rndZ9G84NQl8XJNIhheb8ev8Vo=','2025-10-08 09:21:41.445666',1,'Rakesh','','','rakesh@gmail.com',1,1,'2025-10-08 09:21:12.285727');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` varchar(20) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `customers_username_20254212` (`username`),
  KEY `customers_usernam_fad06d_idx` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'aswini','aswini@example.com','customer','2025-10-06 12:49:22.172114'),(2,'siva','siva@example.com','customer','2025-10-06 13:11:16.152096');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'auth','user'),(5,'contenttypes','contenttype'),(6,'sessions','session'),(7,'shop_management','customers'),(10,'shop_management','customsession'),(11,'shop_management','orders'),(8,'shop_management','products'),(9,'shop_management','shopkeepers');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2025-10-06 12:05:36.784321'),(2,'auth','0001_initial','2025-10-06 12:05:39.487592'),(3,'admin','0001_initial','2025-10-06 12:05:40.050158'),(4,'admin','0002_logentry_remove_auto_add','2025-10-06 12:05:40.088995'),(5,'admin','0003_logentry_add_action_flag_choices','2025-10-06 12:05:40.132107'),(6,'contenttypes','0002_remove_content_type_name','2025-10-06 12:05:40.656963'),(7,'auth','0002_alter_permission_name_max_length','2025-10-06 12:05:40.852425'),(8,'auth','0003_alter_user_email_max_length','2025-10-06 12:05:40.930500'),(9,'auth','0004_alter_user_username_opts','2025-10-06 12:05:40.949813'),(10,'auth','0005_alter_user_last_login_null','2025-10-06 12:05:41.146925'),(11,'auth','0006_require_contenttypes_0002','2025-10-06 12:05:41.164817'),(12,'auth','0007_alter_validators_add_error_messages','2025-10-06 12:05:41.206956'),(13,'auth','0008_alter_user_username_max_length','2025-10-06 12:05:41.533253'),(14,'auth','0009_alter_user_last_name_max_length','2025-10-06 12:05:41.845319'),(15,'auth','0010_alter_group_name_max_length','2025-10-06 12:05:41.952644'),(16,'auth','0011_update_proxy_permissions','2025-10-06 12:05:42.000092'),(17,'auth','0012_alter_user_first_name_max_length','2025-10-06 12:05:42.324608'),(18,'sessions','0001_initial','2025-10-06 12:05:42.530633'),(20,'shop_management','0001_initial','2025-10-06 12:41:45.245069'),(21,'shop_management','0002_products_created_by','2025-10-07 04:22:58.067413'),(22,'shop_management','0003_alter_customsession_session_id','2025-10-07 06:16:20.817273'),(23,'shop_management','0004_remove_products_created_by_and_more','2025-10-07 06:16:50.675266'),(24,'shop_management','0005_products_created_by_alter_customsession_session_id','2025-10-07 06:17:21.891511');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('4olyoq034517i39grr0n6721tu1noc7i','.eJxVjEEOwiAQRe_C2pAZLAou3fcMZBgGqRpISrsy3l2bdKHb_977LxVoXUpYu8xhSuqiUB1-t0j8kLqBdKd6a5pbXeYp6k3RO-16bEme1939OyjUy7cmYRvJuWx8HMTkhGgHexYB4623TEdhQRCfnY0JMyQGMCfw4iI7RPX-AAIZOFw:1v6QMf:P0UdHTy2jPGgsjWm_EckzmNR6bx4B3fKWmTvgrITNJw','2025-10-22 09:21:41.457358');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `quantity` int NOT NULL,
  `order_date` datetime(6) DEFAULT NULL,
  `customer_id` bigint DEFAULT NULL,
  `product_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `orders_product_id_410f7af4_fk_products_id` (`product_id`),
  KEY `orders_order_date_20533752` (`order_date`),
  KEY `orders_custome_c0f6f7_idx` (`customer_id`,`product_id`),
  KEY `orders_order_d_6e39a9_idx` (`order_date`),
  CONSTRAINT `orders_customer_id_b7016332_fk_customers_id` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `orders_product_id_410f7af4_fk_products_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,2,'2025-10-07 07:40:21.307784',1,1),(2,2,'2025-10-07 07:51:33.539019',1,1),(3,2,'2025-10-08 09:24:48.204388',1,2),(4,2,'2025-10-08 09:24:52.340667',1,3),(5,2,'2025-10-08 09:24:54.509536',1,4),(6,2,'2025-10-08 09:24:56.412328',1,5),(7,2,'2025-10-08 09:24:59.275614',1,7),(8,2,'2025-10-08 12:26:32.499135',1,8),(9,2,'2025-10-08 12:26:36.228493',1,8),(10,3,'2025-10-08 12:28:35.618655',1,9),(11,1,'2025-10-08 12:28:54.133130',1,10),(12,1,'2025-10-09 05:53:06.616824',2,1),(13,1,'2025-10-09 05:53:12.857515',2,2);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int DEFAULT NULL,
  `created_by_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `products_name_4a89b61d` (`name`),
  KEY `products_price_2104b53c` (`price`),
  KEY `products_name_4f706b_idx` (`name`,`price`),
  KEY `products_created_by_id_924ff91a_fk_shopkeepers_id` (`created_by_id`),
  CONSTRAINT `products_created_by_id_924ff91a_fk_shopkeepers_id` FOREIGN KEY (`created_by_id`) REFERENCES `shopkeepers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=273 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Apple iPhone 16',89999.00,15,1),(2,'Apple iPhone 16',89999.00,17,1),(3,'Samsung s24',100000.00,18,1),(4,'mobile',1000.00,18,1),(5,'Licensed Fresh Sausages',863.32,3,1),(6,'Practical Metal Soap',180.36,5,1),(7,'Practical Cotton Computer',556.44,3,1),(8,'Handmade Rubber Chicken',219.28,1,1),(9,'Small Cotton Chicken',971.61,2,1),(10,'Tasty Steel Cheese',65.86,4,1),(11,'Generic Wooden Table',831.32,5,1),(12,'Tasty Wooden Salad',109.52,5,1),(13,'Handmade Concrete Cheese',691.46,5,1),(14,'Gorgeous Soft Chips',635.26,5,1),(15,'Tasty Frozen Pizza',993.00,5,1),(16,'Sleek Granite Chicken',951.74,5,1),(17,'Licensed Wooden Sausages',710.30,5,1),(18,'Incredible Rubber Chair',810.01,5,1),(19,'Refined Metal Salad',370.60,5,1),(20,'Unbranded Granite Keyboard',570.65,5,1),(21,'Practical Fresh Bike',836.61,5,1),(22,'Handcrafted Plastic Keyboard',49.83,5,1),(23,'Small Rubber Pizza',395.75,5,1),(24,'Handmade Rubber Gloves',42.41,5,1),(25,'Gorgeous Fresh Tuna',578.02,5,1),(26,'Laptop',200000.00,100,1),(27,'Handmade Fresh Hat',978.42,5,1),(28,'Tasty Frozen Shoes',217.49,5,1),(29,'Generic Soft Tuna',50.09,5,1),(30,'Refined Metal Shirt',901.01,5,1),(31,'Refined Frozen Car',479.24,5,1),(32,'Gorgeous Granite Keyboard',54.26,5,1),(33,'Handmade Concrete Chips',592.70,5,1),(34,'Intelligent Cotton Bacon',285.38,5,1),(35,'Unbranded Frozen Cheese',509.43,5,1),(36,'Handmade Concrete Soap',545.62,5,1),(37,'Gorgeous Plastic Tuna',564.76,5,1),(38,'Unbranded Fresh Cheese',899.19,5,1),(39,'Small Wooden Mouse',661.91,5,1),(40,'Handmade Wooden Mouse',483.33,5,1),(41,'Fantastic Rubber Ball',345.71,5,1),(42,'Licensed Fresh Pizza',799.04,5,1),(43,'Small Granite Gloves',852.73,5,1),(44,'Rustic Wooden Mouse',41.72,5,1),(45,'Awesome Cotton Car',892.07,5,1),(46,'Generic Plastic Gloves',356.87,5,1),(47,'Small Fresh Salad',696.77,5,1),(48,'Gorgeous Steel Hat',752.21,5,1),(49,'Handmade Steel Tuna',584.40,5,1),(50,'Refined Steel Pants',817.36,5,1),(51,'Small Frozen Computer',850.18,5,1),(52,'Rustic Frozen Cheese',517.53,5,1),(53,'Unbranded Frozen Salad',164.60,5,1),(54,'Licensed Concrete Bacon',684.22,5,1),(55,'Refined Concrete Fish',410.26,NULL,2),(56,'Refined Concrete Fish',410.26,5,2),(57,'Incredible Plastic Keyboard',352.52,NULL,2),(58,'Incredible Plastic Keyboard',352.52,5,2),(59,'Awesome Cotton Salad',387.22,NULL,2),(60,'Awesome Cotton Salad',387.22,5,2),(61,'Ergonomic Steel Gloves',279.26,NULL,2),(62,'Ergonomic Steel Gloves',279.26,5,2),(63,'Rustic Fresh Chicken',835.88,NULL,2),(64,'Rustic Fresh Chicken',835.88,5,2),(65,'Unbranded Rubber Bike',762.25,NULL,2),(66,'Unbranded Rubber Bike',762.25,5,2),(67,'Intelligent Granite Fish',157.90,NULL,2),(68,'Intelligent Granite Fish',157.90,5,2),(69,'Refined Frozen Salad',234.48,NULL,2),(70,'Refined Frozen Salad',234.48,5,2),(71,'Practical Cotton Towels',183.39,NULL,2),(72,'Practical Cotton Towels',183.39,5,2),(73,'Handmade Cotton Bike',296.23,NULL,2),(74,'Handmade Cotton Bike',296.23,5,2),(75,'Refined Rubber Computer',605.15,NULL,2),(76,'Refined Rubber Computer',605.15,5,2),(77,'Intelligent Concrete Keyboard',490.15,NULL,2),(78,'Intelligent Concrete Keyboard',490.15,5,2),(79,'Practical Frozen Car',384.11,NULL,2),(80,'Practical Frozen Car',384.11,5,2),(81,'Fantastic Cotton Table',20.07,NULL,2),(82,'Fantastic Cotton Table',20.07,5,2),(83,'Refined Granite Pizza',161.48,NULL,2),(84,'Refined Granite Pizza',161.48,5,2),(85,'Handmade Plastic Hat',288.85,NULL,2),(86,'Handmade Plastic Hat',288.85,5,2),(87,'Tasty Soft Sausages',333.17,NULL,2),(88,'Tasty Soft Sausages',333.17,5,2),(89,'Generic Frozen Pants',157.05,NULL,2),(90,'Generic Frozen Pants',157.05,5,2),(91,'Rustic Concrete Computer',777.43,NULL,2),(92,'Rustic Concrete Computer',777.43,5,2),(93,'Handmade Cotton Pants',552.76,NULL,2),(94,'Handmade Cotton Pants',552.76,5,2),(95,'Rustic Rubber Towels',543.12,NULL,2),(96,'Rustic Rubber Towels',543.12,5,2),(97,'Small Cotton Ball',870.97,NULL,2),(98,'Small Cotton Ball',870.97,5,2),(99,'Sleek Granite Sausages',388.09,NULL,2),(100,'Sleek Granite Sausages',388.09,5,2),(101,'Small Soft Ball',672.70,NULL,2),(102,'Small Soft Ball',672.70,5,2),(103,'Rustic Fresh Car',123.91,NULL,2),(104,'Rustic Fresh Car',123.91,5,2),(105,'Sleek Granite Car',38.04,NULL,2),(106,'Sleek Granite Car',38.04,5,2),(107,'Unbranded Frozen Gloves',501.98,NULL,2),(108,'Unbranded Frozen Gloves',501.98,5,2),(109,'Gorgeous Granite Bacon',13.16,NULL,2),(110,'Gorgeous Granite Bacon',13.16,5,2),(111,'Sleek Cotton Chips',851.09,NULL,2),(112,'Sleek Cotton Chips',851.09,5,2),(113,'Sleek Steel Ball',201.54,NULL,2),(114,'Sleek Steel Ball',201.54,5,2),(115,'Ergonomic Granite Hat',956.66,NULL,2),(116,'Ergonomic Granite Hat',956.66,5,2),(117,'Rustic Steel Hat',795.32,NULL,2),(118,'Rustic Steel Hat',795.32,5,2),(119,'Generic Concrete Chips',491.27,NULL,2),(120,'Generic Concrete Chips',491.27,5,2),(121,'Incredible Plastic Bacon',36.02,NULL,2),(122,'Incredible Plastic Bacon',36.02,5,2),(123,'Unbranded Frozen Car',822.37,NULL,2),(124,'Unbranded Frozen Car',822.37,5,2),(125,'Generic Plastic Pizza',313.20,NULL,2),(126,'Generic Plastic Pizza',313.20,5,2),(127,'Gorgeous Frozen Fish',315.00,NULL,2),(128,'Gorgeous Frozen Fish',315.00,5,2),(129,'Gorgeous Wooden Salad',914.53,NULL,2),(130,'Gorgeous Wooden Salad',914.53,5,2),(131,'Awesome Soft Hat',601.52,NULL,2),(132,'Awesome Soft Hat',601.52,5,2),(133,'Handmade Frozen Shoes',730.44,NULL,2),(134,'Handmade Frozen Shoes',730.44,5,2),(135,'Tasty Granite Chips',625.93,NULL,2),(136,'Tasty Granite Chips',625.93,5,2),(137,'Refined Soft Shoes',170.53,NULL,2),(138,'Refined Soft Shoes',170.53,5,2),(139,'Refined Fresh Car',203.57,NULL,2),(140,'Refined Fresh Car',203.57,5,2),(141,'Sleek Cotton Chicken',994.10,NULL,2),(142,'Sleek Cotton Chicken',994.10,5,2),(143,'Tasty Rubber Pants',46.99,NULL,2),(144,'Tasty Rubber Pants',46.99,5,2),(145,'Small Plastic Bacon',118.51,NULL,2),(146,'Small Plastic Bacon',118.51,5,2),(147,'Sleek Cotton Shoes',685.09,NULL,2),(148,'Sleek Cotton Shoes',685.09,5,2),(149,'Tasty Concrete Gloves',210.37,NULL,2),(150,'Tasty Concrete Gloves',210.37,5,2),(151,'Gorgeous Steel Fish',400.15,NULL,2),(152,'Gorgeous Steel Fish',400.15,5,2),(153,'Awesome Fresh Table',700.53,NULL,2),(154,'Awesome Fresh Table',700.53,5,2),(155,'Awesome Metal Towels',782.19,NULL,2),(156,'Awesome Metal Towels',782.19,5,2),(157,'Refined Fresh Salad',856.72,NULL,2),(158,'Refined Fresh Salad',856.72,5,2),(159,'Sleek Metal Car',467.57,NULL,2),(160,'Sleek Metal Car',467.57,5,2),(161,'Incredible Plastic Ball',445.26,NULL,2),(162,'Incredible Plastic Ball',445.26,5,2),(163,'Practical Concrete Mouse',991.85,NULL,2),(164,'Practical Concrete Mouse',991.85,5,2),(165,'Practical Soft Chicken',859.78,NULL,2),(166,'Practical Soft Chicken',859.78,5,2),(167,'Rustic Cotton Computer',330.87,NULL,2),(168,'Rustic Cotton Computer',330.87,5,2),(169,'Intelligent Metal Chicken',797.54,NULL,2),(170,'Intelligent Metal Chicken',797.54,5,2),(171,'Rustic Metal Ball',251.56,NULL,2),(172,'Rustic Metal Ball',251.56,5,2),(173,'Handmade Soft Gloves',75.91,NULL,2),(174,'Handmade Soft Gloves',75.91,5,2),(175,'Fantastic Plastic Ball',229.53,NULL,2),(176,'Fantastic Plastic Ball',229.53,5,2),(177,'Licensed Frozen Shoes',53.56,NULL,2),(178,'Licensed Frozen Shoes',53.56,5,2),(179,'Incredible Rubber Computer',91.36,NULL,2),(180,'Incredible Rubber Computer',91.36,5,2),(181,'Unbranded Fresh Bacon',830.33,NULL,2),(182,'Unbranded Fresh Bacon',830.33,5,2),(183,'Handmade Fresh Shirt',680.71,NULL,2),(184,'Handmade Fresh Shirt',680.71,5,2),(185,'Sleek Steel Hat',470.64,NULL,2),(186,'Sleek Steel Hat',470.64,5,2),(187,'Handcrafted Concrete Salad',840.12,NULL,2),(188,'Handcrafted Concrete Salad',840.12,5,2),(189,'Tasty Granite Tuna',749.25,NULL,2),(190,'Tasty Granite Tuna',749.25,5,2),(191,'Fantastic Plastic Keyboard',679.19,NULL,2),(192,'Fantastic Plastic Keyboard',679.19,5,2),(193,'Tasty Rubber Tuna',674.86,NULL,2),(194,'Tasty Rubber Tuna',674.86,5,2),(195,'Tasty Concrete Chair',273.25,NULL,2),(196,'Tasty Concrete Chair',273.25,5,2),(197,'Licensed Frozen Table',428.06,NULL,2),(198,'Licensed Frozen Table',428.06,5,2),(199,'Licensed Steel Ball',903.09,NULL,2),(200,'Licensed Steel Ball',903.09,5,2),(201,'Fantastic Rubber Hat',491.97,NULL,2),(202,'Fantastic Rubber Hat',491.97,5,2),(203,'Handmade Soft Pants',587.78,NULL,2),(204,'Handmade Soft Pants',587.78,5,2),(205,'Handmade Fresh Shirt',955.79,NULL,2),(206,'Handmade Fresh Shirt',955.79,5,2),(207,'Awesome Plastic Soap',851.12,NULL,2),(208,'Awesome Plastic Soap',851.12,5,2),(209,'Sleek Cotton Keyboard',145.79,NULL,2),(210,'Sleek Cotton Keyboard',145.79,5,2),(211,'Small Frozen Hat',98.10,NULL,2),(212,'Small Frozen Hat',98.10,5,2),(213,'Rustic Metal Salad',803.47,NULL,2),(214,'Rustic Metal Salad',803.47,5,2),(215,'Awesome Soft Gloves',761.65,NULL,2),(216,'Awesome Soft Gloves',761.65,5,2),(217,'Handcrafted Cotton Towels',532.39,NULL,2),(218,'Handcrafted Cotton Towels',532.39,5,2),(219,'Small Concrete Car',140.53,NULL,2),(220,'Small Concrete Car',140.53,5,2),(221,'Generic Fresh Keyboard',216.64,NULL,2),(222,'Generic Fresh Keyboard',216.64,5,2),(223,'Ergonomic Cotton Car',332.66,NULL,2),(224,'Ergonomic Cotton Car',332.66,5,2),(225,'Fantastic Granite Cheese',500.07,NULL,2),(226,'Fantastic Granite Cheese',500.07,5,2),(227,'Unbranded Frozen Salad',567.46,NULL,2),(228,'Unbranded Frozen Salad',567.46,5,2),(229,'Intelligent Soft Chair',111.88,NULL,2),(230,'Intelligent Soft Chair',111.88,5,2),(231,'Handmade Frozen Chair',649.05,NULL,2),(232,'Handmade Frozen Chair',649.05,5,2),(233,'Handcrafted Soft Shoes',488.95,NULL,2),(234,'Handcrafted Soft Shoes',488.95,5,2),(235,'Practical Wooden Bike',554.94,NULL,2),(236,'Practical Wooden Bike',554.94,5,2),(237,'Fantastic Plastic Bacon',49.95,NULL,2),(238,'Fantastic Plastic Bacon',49.95,5,2),(239,'Refined Fresh Chicken',423.16,NULL,2),(240,'Refined Fresh Chicken',423.16,5,2),(241,'Awesome Granite Towels',589.38,NULL,2),(242,'Awesome Granite Towels',589.38,5,2),(243,'Refined Wooden Bike',12.07,NULL,2),(244,'Refined Wooden Bike',12.07,5,2),(245,'Handmade Wooden Fish',411.42,NULL,2),(246,'Handmade Wooden Fish',411.42,5,2),(247,'Fantastic Granite Chips',356.46,NULL,2),(248,'Fantastic Granite Chips',356.46,5,2),(249,'Small Soft Hat',641.71,NULL,2),(250,'Small Soft Hat',641.71,5,2),(251,'Rustic Steel Computer',733.92,NULL,2),(252,'Rustic Steel Computer',733.92,5,2),(253,'Awesome Steel Towels',679.66,NULL,2),(254,'Awesome Steel Towels',679.66,5,2),(255,'Tasty Rubber Computer',345.79,NULL,2),(256,'Tasty Rubber Computer',345.79,5,2),(257,'Incredible Fresh Car',240.00,NULL,2),(258,'Incredible Fresh Car',240.00,5,2),(259,'Intelligent Cotton Fish',0.26,NULL,2),(260,'Intelligent Cotton Fish',0.26,5,2),(261,'Ergonomic Steel Computer',387.20,NULL,2),(262,'Ergonomic Steel Computer',387.20,5,2),(263,'Sleek Soft Towels',771.32,NULL,2),(264,'Sleek Soft Towels',771.32,5,2),(265,'Intelligent Fresh Soap',297.47,NULL,2),(266,'Intelligent Fresh Soap',297.47,5,2),(267,'Practical Fresh Shirt',571.34,NULL,1),(268,'Practical Fresh Shirt',571.34,5,1),(269,'Ergonomic Fresh Bacon',564.96,NULL,1),(270,'Ergonomic Fresh Bacon',564.96,5,1),(271,'Handcrafted Fresh Hat',486.51,NULL,1),(272,'Handcrafted Fresh Hat',486.51,5,1);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_management_customsession`
--

DROP TABLE IF EXISTS `shop_management_customsession`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_management_customsession` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `session_id` varchar(64) NOT NULL,
  `privileges` json NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `expires_at` datetime(6) NOT NULL,
  `mode` varchar(20) NOT NULL,
  `customer_id` bigint DEFAULT NULL,
  `shopkeeper_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_id` (`session_id`),
  KEY `shop_management_cust_customer_id_cd8ad6b4_fk_customers` (`customer_id`),
  KEY `shop_management_cust_shopkeeper_id_65370539_fk_shopkeepe` (`shopkeeper_id`),
  CONSTRAINT `shop_management_cust_customer_id_cd8ad6b4_fk_customers` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `shop_management_cust_shopkeeper_id_65370539_fk_shopkeepe` FOREIGN KEY (`shopkeeper_id`) REFERENCES `shopkeepers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_management_customsession`
--

LOCK TABLES `shop_management_customsession` WRITE;
/*!40000 ALTER TABLE `shop_management_customsession` DISABLE KEYS */;
INSERT INTO `shop_management_customsession` VALUES (65,'9bf3e067-07b4-4510-888a-6fc526781e06','{\"can_edit\": true, \"can_delete\": false}','2025-10-10 10:29:40.558398','2025-10-10 14:29:40.555405','single',NULL,1);
/*!40000 ALTER TABLE `shop_management_customsession` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopkeepers`
--

DROP TABLE IF EXISTS `shopkeepers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shopkeepers` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` varchar(20) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `shopkeepers_username_6c4d0739` (`username`),
  KEY `shopkeepers_usernam_2540e7_idx` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopkeepers`
--

LOCK TABLES `shopkeepers` WRITE;
/*!40000 ALTER TABLE `shopkeepers` DISABLE KEYS */;
INSERT INTO `shopkeepers` VALUES (1,'rakesh','rakesh@example.com','shopkeeper','2025-10-06 12:42:06.823387'),(2,'mani','mani@example.com','shopkeeper','2025-10-06 13:07:13.671594');
/*!40000 ALTER TABLE `shopkeepers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-10 17:38:24
