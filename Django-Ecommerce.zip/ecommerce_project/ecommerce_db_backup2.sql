-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: ecommerce_db
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add customers',7,'add_customers'),(26,'Can change customers',7,'change_customers'),(27,'Can delete customers',7,'delete_customers'),(28,'Can view customers',7,'view_customers'),(29,'Can add products',8,'add_products'),(30,'Can change products',8,'change_products'),(31,'Can delete products',8,'delete_products'),(32,'Can view products',8,'view_products'),(33,'Can add shopkeepers',9,'add_shopkeepers'),(34,'Can change shopkeepers',9,'change_shopkeepers'),(35,'Can delete shopkeepers',9,'delete_shopkeepers'),(36,'Can view shopkeepers',9,'view_shopkeepers'),(37,'Can add custom session',10,'add_customsession'),(38,'Can change custom session',10,'change_customsession'),(39,'Can delete custom session',10,'delete_customsession'),(40,'Can view custom session',10,'view_customsession'),(41,'Can add orders',11,'add_orders'),(42,'Can change orders',11,'change_orders'),(43,'Can delete orders',11,'delete_orders'),(44,'Can view orders',11,'view_orders'),(45,'Can add categories',12,'add_categories'),(46,'Can change categories',12,'change_categories'),(47,'Can delete categories',12,'delete_categories'),(48,'Can view categories',12,'view_categories'),(49,'Can add carts',13,'add_carts'),(50,'Can change carts',13,'change_carts'),(51,'Can delete carts',13,'delete_carts'),(52,'Can view carts',13,'view_carts'),(53,'Can add cart items',14,'add_cartitems'),(54,'Can change cart items',14,'change_cartitems'),(55,'Can delete cart items',14,'delete_cartitems'),(56,'Can view cart items',14,'view_cartitems'),(57,'Can add notifications',15,'add_notifications'),(58,'Can change notifications',15,'change_notifications'),(59,'Can delete notifications',15,'delete_notifications'),(60,'Can view notifications',15,'view_notifications'),(61,'Can add promotions',16,'add_promotions'),(62,'Can change promotions',16,'change_promotions'),(63,'Can delete promotions',16,'delete_promotions'),(64,'Can view promotions',16,'view_promotions'),(65,'Can add reviews',17,'add_reviews'),(66,'Can change reviews',17,'change_reviews'),(67,'Can delete reviews',17,'delete_reviews'),(68,'Can view reviews',17,'view_reviews'),(69,'Can add wishlists',18,'add_wishlists'),(70,'Can change wishlists',18,'change_wishlists'),(71,'Can delete wishlists',18,'delete_wishlists'),(72,'Can view wishlists',18,'view_wishlists');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (4,'pbkdf2_sha256$1000000$Dc7qmg7Dnr9eSZY2kT480H$Mk8I9e1f6h2k6Olv4/Pa0tS2TWfZkiBXFm17ed13s0g=',NULL,1,'Rakesh','','','rakesh01@gmail.com',1,1,'2025-10-14 05:24:27.654686');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` varchar(20) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `address` longtext,
  `deleted_at` datetime(6) DEFAULT NULL,
  `loyalyty_points` int NOT NULL,
  `phone_number` bigint NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `password` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `customers_username_20254212` (`username`),
  KEY `customers_usernam_c6437f_idx` (`username`,`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'aswini','aswini@example.com','customer','2025-10-06 12:49:22.172114',NULL,NULL,0,8089096590,'2025-10-10 12:15:31.428790',NULL),(2,'siva','siva@example.com','customer','2025-10-06 13:11:16.152096',NULL,NULL,0,8089096590,'2025-10-10 12:15:31.428790',NULL),(5,'customer1','customer1@example.com','customer','2025-10-14 07:12:03.629205','456 Elm Street, City, Country',NULL,0,9000000001,'2025-10-14 07:12:03.629257','pbkdf2_sha256$1000000$zNDiO0JopUaFNTsdPoKVHs$3nUfHbGS5XxNGNr0ltA+abq34hZTBzH1+48D3zX7q9g=');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'auth','user'),(5,'contenttypes','contenttype'),(6,'sessions','session'),(14,'shop_management','cartitems'),(13,'shop_management','carts'),(12,'shop_management','categories'),(7,'shop_management','customers'),(10,'shop_management','customsession'),(15,'shop_management','notifications'),(11,'shop_management','orders'),(8,'shop_management','products'),(16,'shop_management','promotions'),(17,'shop_management','reviews'),(9,'shop_management','shopkeepers'),(18,'shop_management','wishlists');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2025-10-06 12:05:36.784321'),(2,'auth','0001_initial','2025-10-06 12:05:39.487592'),(3,'admin','0001_initial','2025-10-06 12:05:40.050158'),(4,'admin','0002_logentry_remove_auto_add','2025-10-06 12:05:40.088995'),(5,'admin','0003_logentry_add_action_flag_choices','2025-10-06 12:05:40.132107'),(6,'contenttypes','0002_remove_content_type_name','2025-10-06 12:05:40.656963'),(7,'auth','0002_alter_permission_name_max_length','2025-10-06 12:05:40.852425'),(8,'auth','0003_alter_user_email_max_length','2025-10-06 12:05:40.930500'),(9,'auth','0004_alter_user_username_opts','2025-10-06 12:05:40.949813'),(10,'auth','0005_alter_user_last_login_null','2025-10-06 12:05:41.146925'),(11,'auth','0006_require_contenttypes_0002','2025-10-06 12:05:41.164817'),(12,'auth','0007_alter_validators_add_error_messages','2025-10-06 12:05:41.206956'),(13,'auth','0008_alter_user_username_max_length','2025-10-06 12:05:41.533253'),(14,'auth','0009_alter_user_last_name_max_length','2025-10-06 12:05:41.845319'),(15,'auth','0010_alter_group_name_max_length','2025-10-06 12:05:41.952644'),(16,'auth','0011_update_proxy_permissions','2025-10-06 12:05:42.000092'),(17,'auth','0012_alter_user_first_name_max_length','2025-10-06 12:05:42.324608'),(18,'sessions','0001_initial','2025-10-06 12:05:42.530633'),(20,'shop_management','0001_initial','2025-10-06 12:41:45.245069'),(21,'shop_management','0002_products_created_by','2025-10-07 04:22:58.067413'),(22,'shop_management','0003_alter_customsession_session_id','2025-10-07 06:16:20.817273'),(23,'shop_management','0004_remove_products_created_by_and_more','2025-10-07 06:16:50.675266'),(24,'shop_management','0005_products_created_by_alter_customsession_session_id','2025-10-07 06:17:21.891511'),(25,'shop_management','0006_categories_remove_customsession_mode_and_more','2025-10-10 12:15:34.944542'),(26,'shop_management','0007_alter_customers_phone_number_and_more','2025-10-10 12:19:16.473007'),(27,'shop_management','0008_customsession_superuser_alter_customers_phone_number_and_more','2025-10-13 10:11:05.360206'),(30,'shop_management','0009_rename_superuser_customsession_user_and_more','2025-10-13 10:46:01.868460'),(31,'shop_management','0010_remove_customers_customers_usernam_fad06d_idx_and_more','2025-10-14 06:37:04.137183'),(32,'shop_management','0011_rename_sold_out_products_total_sold_and_more','2025-10-14 08:22:00.970197');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('4olyoq034517i39grr0n6721tu1noc7i','.eJxVjEEOwiAQRe_C2pAZLAou3fcMZBgGqRpISrsy3l2bdKHb_977LxVoXUpYu8xhSuqiUB1-t0j8kLqBdKd6a5pbXeYp6k3RO-16bEme1939OyjUy7cmYRvJuWx8HMTkhGgHexYB4623TEdhQRCfnY0JMyQGMCfw4iI7RPX-AAIZOFw:1v6QMf:P0UdHTy2jPGgsjWm_EckzmNR6bx4B3fKWmTvgrITNJw','2025-10-22 09:21:41.457358');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `quantity` int NOT NULL,
  `order_date` datetime(6) DEFAULT NULL,
  `customer_id` bigint DEFAULT NULL,
  `product_id` bigint DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `shipping_address` longtext,
  `status` varchar(20) NOT NULL,
  `transaction_id` varchar(100) DEFAULT NULL,
  KEY `orders_product_id_410f7af4_fk_products_id` (`product_id`),
  KEY `orders_order_date_20533752` (`order_date`),
  KEY `orders_custome_c0f6f7_idx` (`customer_id`,`product_id`),
  KEY `orders_order_d_6e39a9_idx` (`order_date`),
  CONSTRAINT `orders_customer_id_b7016332_fk_customers_id` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `orders_product_id_410f7af4_fk_products_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int NOT NULL,
  `created_by_id` bigint DEFAULT NULL,
  `description` longtext NOT NULL,
  `discount_price` decimal(10,2) DEFAULT NULL,
  `rating` decimal(3,2) NOT NULL,
  `total_sold` int NOT NULL,
  `category_id` bigint DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `products_name_4a89b61d` (`name`),
  KEY `products_price_2104b53c` (`price`),
  KEY `products_name_4f706b_idx` (`name`,`price`),
  KEY `products_created_by_id_924ff91a_fk_shopkeepers_id` (`created_by_id`),
  KEY `products_category_id_a7a3a156_fk_shop_management_categories_id` (`category_id`),
  CONSTRAINT `products_category_id_a7a3a156_fk_shop_management_categories_id` FOREIGN KEY (`category_id`) REFERENCES `shop_management_categories` (`id`),
  CONSTRAINT `products_created_by_id_924ff91a_fk_shopkeepers_id` FOREIGN KEY (`created_by_id`) REFERENCES `shopkeepers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=424 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Apple iPhone 16',89999.00,15,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(2,'Apple iPhone 16',89999.00,17,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(3,'Samsung s24',100000.00,18,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(4,'mobile',1000.00,18,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(5,'Licensed Fresh Sausages',863.32,3,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(6,'Practical Metal Soap',180.36,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(7,'Practical Cotton Computer',556.44,3,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(8,'Handmade Rubber Chicken',219.28,1,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(9,'Small Cotton Chicken',971.61,2,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(10,'Tasty Steel Cheese',65.86,4,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(11,'Generic Wooden Table',831.32,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(12,'Tasty Wooden Salad',109.52,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(13,'Handmade Concrete Cheese',691.46,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(14,'Gorgeous Soft Chips',635.26,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(15,'Tasty Frozen Pizza',993.00,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(16,'Sleek Granite Chicken',951.74,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(17,'Licensed Wooden Sausages',710.30,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(18,'Incredible Rubber Chair',810.01,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(19,'Refined Metal Salad',370.60,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(20,'Unbranded Granite Keyboard',570.65,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(21,'Practical Fresh Bike',836.61,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(22,'Handcrafted Plastic Keyboard',49.83,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(23,'Small Rubber Pizza',395.75,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(24,'Handmade Rubber Gloves',42.41,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(25,'Gorgeous Fresh Tuna',578.02,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(26,'Laptop',200000.00,100,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(27,'Handmade Fresh Hat',978.42,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(28,'Tasty Frozen Shoes',217.49,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(29,'Generic Soft Tuna',50.09,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(30,'Refined Metal Shirt',901.01,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(31,'Refined Frozen Car',479.24,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(32,'Gorgeous Granite Keyboard',54.26,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(33,'Handmade Concrete Chips',592.70,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(34,'Intelligent Cotton Bacon',285.38,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(35,'Unbranded Frozen Cheese',509.43,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(36,'Handmade Concrete Soap',545.62,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(37,'Gorgeous Plastic Tuna',564.76,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(38,'Unbranded Fresh Cheese',899.19,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(39,'Small Wooden Mouse',661.91,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(40,'Handmade Wooden Mouse',483.33,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(41,'Fantastic Rubber Ball',345.71,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(42,'Licensed Fresh Pizza',799.04,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(43,'Small Granite Gloves',852.73,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(44,'Rustic Wooden Mouse',41.72,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(45,'Awesome Cotton Car',892.07,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(46,'Generic Plastic Gloves',356.87,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(47,'Small Fresh Salad',696.77,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(48,'Gorgeous Steel Hat',752.21,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(49,'Handmade Steel Tuna',584.40,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(50,'Refined Steel Pants',817.36,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(51,'Small Frozen Computer',850.18,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(52,'Rustic Frozen Cheese',517.53,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(53,'Unbranded Frozen Salad',164.60,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(54,'Licensed Concrete Bacon',684.22,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(55,'Refined Concrete Fish',410.26,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(56,'Refined Concrete Fish',410.26,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(57,'Incredible Plastic Keyboard',352.52,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(58,'Incredible Plastic Keyboard',352.52,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(59,'Awesome Cotton Salad',387.22,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(60,'Awesome Cotton Salad',387.22,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(61,'Ergonomic Steel Gloves',279.26,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(62,'Ergonomic Steel Gloves',279.26,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(63,'Rustic Fresh Chicken',835.88,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(64,'Rustic Fresh Chicken',835.88,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(65,'Unbranded Rubber Bike',762.25,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(66,'Unbranded Rubber Bike',762.25,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(67,'Intelligent Granite Fish',157.90,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(68,'Intelligent Granite Fish',157.90,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(69,'Refined Frozen Salad',234.48,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(70,'Refined Frozen Salad',234.48,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(71,'Practical Cotton Towels',183.39,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(72,'Practical Cotton Towels',183.39,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(73,'Handmade Cotton Bike',296.23,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(74,'Handmade Cotton Bike',296.23,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(75,'Refined Rubber Computer',605.15,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(76,'Refined Rubber Computer',605.15,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(77,'Intelligent Concrete Keyboard',490.15,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(78,'Intelligent Concrete Keyboard',490.15,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(79,'Practical Frozen Car',384.11,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(80,'Practical Frozen Car',384.11,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(81,'Fantastic Cotton Table',20.07,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(82,'Fantastic Cotton Table',20.07,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(83,'Refined Granite Pizza',161.48,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(84,'Refined Granite Pizza',161.48,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(85,'Handmade Plastic Hat',288.85,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(86,'Handmade Plastic Hat',288.85,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(87,'Tasty Soft Sausages',333.17,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(88,'Tasty Soft Sausages',333.17,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(89,'Generic Frozen Pants',157.05,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(90,'Generic Frozen Pants',157.05,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(91,'Rustic Concrete Computer',777.43,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(92,'Rustic Concrete Computer',777.43,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(93,'Handmade Cotton Pants',552.76,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(94,'Handmade Cotton Pants',552.76,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(95,'Rustic Rubber Towels',543.12,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(96,'Rustic Rubber Towels',543.12,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(97,'Small Cotton Ball',870.97,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(98,'Small Cotton Ball',870.97,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(99,'Sleek Granite Sausages',388.09,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(100,'Sleek Granite Sausages',388.09,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(101,'Small Soft Ball',672.70,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(102,'Small Soft Ball',672.70,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(103,'Rustic Fresh Car',123.91,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(104,'Rustic Fresh Car',123.91,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(105,'Sleek Granite Car',38.04,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(106,'Sleek Granite Car',38.04,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(107,'Unbranded Frozen Gloves',501.98,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(108,'Unbranded Frozen Gloves',501.98,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(109,'Gorgeous Granite Bacon',13.16,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(110,'Gorgeous Granite Bacon',13.16,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(111,'Sleek Cotton Chips',851.09,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(112,'Sleek Cotton Chips',851.09,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(113,'Sleek Steel Ball',201.54,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(114,'Sleek Steel Ball',201.54,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(115,'Ergonomic Granite Hat',956.66,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(116,'Ergonomic Granite Hat',956.66,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(117,'Rustic Steel Hat',795.32,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(118,'Rustic Steel Hat',795.32,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(119,'Generic Concrete Chips',491.27,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(120,'Generic Concrete Chips',491.27,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(121,'Incredible Plastic Bacon',36.02,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(122,'Incredible Plastic Bacon',36.02,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(123,'Unbranded Frozen Car',822.37,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(124,'Unbranded Frozen Car',822.37,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(125,'Generic Plastic Pizza',313.20,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(126,'Generic Plastic Pizza',313.20,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(127,'Gorgeous Frozen Fish',315.00,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(128,'Gorgeous Frozen Fish',315.00,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(129,'Gorgeous Wooden Salad',914.53,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(130,'Gorgeous Wooden Salad',914.53,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(131,'Awesome Soft Hat',601.52,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(132,'Awesome Soft Hat',601.52,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(133,'Handmade Frozen Shoes',730.44,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(134,'Handmade Frozen Shoes',730.44,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(135,'Tasty Granite Chips',625.93,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(136,'Tasty Granite Chips',625.93,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(137,'Refined Soft Shoes',170.53,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(138,'Refined Soft Shoes',170.53,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(139,'Refined Fresh Car',203.57,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(140,'Refined Fresh Car',203.57,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(141,'Sleek Cotton Chicken',994.10,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(142,'Sleek Cotton Chicken',994.10,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(143,'Tasty Rubber Pants',46.99,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(144,'Tasty Rubber Pants',46.99,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(145,'Small Plastic Bacon',118.51,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(146,'Small Plastic Bacon',118.51,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(147,'Sleek Cotton Shoes',685.09,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(148,'Sleek Cotton Shoes',685.09,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(149,'Tasty Concrete Gloves',210.37,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(150,'Tasty Concrete Gloves',210.37,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(151,'Gorgeous Steel Fish',400.15,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(152,'Gorgeous Steel Fish',400.15,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(153,'Awesome Fresh Table',700.53,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(154,'Awesome Fresh Table',700.53,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(155,'Awesome Metal Towels',782.19,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(156,'Awesome Metal Towels',782.19,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(157,'Refined Fresh Salad',856.72,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(158,'Refined Fresh Salad',856.72,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(159,'Sleek Metal Car',467.57,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(160,'Sleek Metal Car',467.57,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(161,'Incredible Plastic Ball',445.26,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(162,'Incredible Plastic Ball',445.26,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(163,'Practical Concrete Mouse',991.85,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(164,'Practical Concrete Mouse',991.85,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(165,'Practical Soft Chicken',859.78,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(166,'Practical Soft Chicken',859.78,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(167,'Rustic Cotton Computer',330.87,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(168,'Rustic Cotton Computer',330.87,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(169,'Intelligent Metal Chicken',797.54,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(170,'Intelligent Metal Chicken',797.54,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(171,'Rustic Metal Ball',251.56,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(172,'Rustic Metal Ball',251.56,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(173,'Handmade Soft Gloves',75.91,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(174,'Handmade Soft Gloves',75.91,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(175,'Fantastic Plastic Ball',229.53,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(176,'Fantastic Plastic Ball',229.53,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(177,'Licensed Frozen Shoes',53.56,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(178,'Licensed Frozen Shoes',53.56,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(179,'Incredible Rubber Computer',91.36,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(180,'Incredible Rubber Computer',91.36,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(181,'Unbranded Fresh Bacon',830.33,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(182,'Unbranded Fresh Bacon',830.33,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(183,'Handmade Fresh Shirt',680.71,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(184,'Handmade Fresh Shirt',680.71,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(185,'Sleek Steel Hat',470.64,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(186,'Sleek Steel Hat',470.64,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(187,'Handcrafted Concrete Salad',840.12,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(188,'Handcrafted Concrete Salad',840.12,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(189,'Tasty Granite Tuna',749.25,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(190,'Tasty Granite Tuna',749.25,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(191,'Fantastic Plastic Keyboard',679.19,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(192,'Fantastic Plastic Keyboard',679.19,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(193,'Tasty Rubber Tuna',674.86,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(194,'Tasty Rubber Tuna',674.86,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(195,'Tasty Concrete Chair',273.25,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(196,'Tasty Concrete Chair',273.25,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(197,'Licensed Frozen Table',428.06,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(198,'Licensed Frozen Table',428.06,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(199,'Licensed Steel Ball',903.09,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(200,'Licensed Steel Ball',903.09,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(201,'Fantastic Rubber Hat',491.97,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(202,'Fantastic Rubber Hat',491.97,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(203,'Handmade Soft Pants',587.78,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(204,'Handmade Soft Pants',587.78,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(205,'Handmade Fresh Shirt',955.79,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(206,'Handmade Fresh Shirt',955.79,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(207,'Awesome Plastic Soap',851.12,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(208,'Awesome Plastic Soap',851.12,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(209,'Sleek Cotton Keyboard',145.79,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(210,'Sleek Cotton Keyboard',145.79,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(211,'Small Frozen Hat',98.10,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(212,'Small Frozen Hat',98.10,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(213,'Rustic Metal Salad',803.47,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(214,'Rustic Metal Salad',803.47,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(215,'Awesome Soft Gloves',761.65,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(216,'Awesome Soft Gloves',761.65,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(217,'Handcrafted Cotton Towels',532.39,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(218,'Handcrafted Cotton Towels',532.39,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(219,'Small Concrete Car',140.53,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(220,'Small Concrete Car',140.53,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(221,'Generic Fresh Keyboard',216.64,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(222,'Generic Fresh Keyboard',216.64,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(223,'Ergonomic Cotton Car',332.66,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(224,'Ergonomic Cotton Car',332.66,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(225,'Fantastic Granite Cheese',500.07,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(226,'Fantastic Granite Cheese',500.07,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(227,'Unbranded Frozen Salad',567.46,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(228,'Unbranded Frozen Salad',567.46,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(229,'Intelligent Soft Chair',111.88,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(230,'Intelligent Soft Chair',111.88,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(231,'Handmade Frozen Chair',649.05,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(232,'Handmade Frozen Chair',649.05,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(233,'Handcrafted Soft Shoes',488.95,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(234,'Handcrafted Soft Shoes',488.95,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(235,'Practical Wooden Bike',554.94,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(236,'Practical Wooden Bike',554.94,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(237,'Fantastic Plastic Bacon',49.95,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(238,'Fantastic Plastic Bacon',49.95,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(239,'Refined Fresh Chicken',423.16,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(240,'Refined Fresh Chicken',423.16,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(241,'Awesome Granite Towels',589.38,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(242,'Awesome Granite Towels',589.38,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(243,'Refined Wooden Bike',12.07,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(244,'Refined Wooden Bike',12.07,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(245,'Handmade Wooden Fish',411.42,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(246,'Handmade Wooden Fish',411.42,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(247,'Fantastic Granite Chips',356.46,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(248,'Fantastic Granite Chips',356.46,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(249,'Small Soft Hat',641.71,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(250,'Small Soft Hat',641.71,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(251,'Rustic Steel Computer',733.92,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(252,'Rustic Steel Computer',733.92,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(253,'Awesome Steel Towels',679.66,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(254,'Awesome Steel Towels',679.66,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(255,'Tasty Rubber Computer',345.79,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(256,'Tasty Rubber Computer',345.79,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(257,'Incredible Fresh Car',240.00,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(258,'Incredible Fresh Car',240.00,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(259,'Intelligent Cotton Fish',0.26,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(260,'Intelligent Cotton Fish',0.26,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(261,'Ergonomic Steel Computer',387.20,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(262,'Ergonomic Steel Computer',387.20,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(263,'Sleek Soft Towels',771.32,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(264,'Sleek Soft Towels',771.32,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(265,'Intelligent Fresh Soap',297.47,0,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(266,'Intelligent Fresh Soap',297.47,5,2,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(267,'Practical Fresh Shirt',571.34,0,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(268,'Practical Fresh Shirt',571.34,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(269,'Ergonomic Fresh Bacon',564.96,0,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(270,'Ergonomic Fresh Bacon',564.96,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(271,'Handcrafted Fresh Hat',486.51,0,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(272,'Handcrafted Fresh Hat',486.51,5,1,'',NULL,0.00,0,NULL,'2025-10-14 08:21:53.554006','2025-10-14 08:21:53.687894'),(273,'Smartphone X100',29999.99,17,5,'Latest smartphone with 128GB storage and 6GB RAM',27999.99,0.00,0,NULL,'2025-10-14 09:21:11.055622','2025-10-14 09:21:11.055712'),(274,'iPhone 15 Pro',1199.99,50,5,'Apple iPhone 15 Pro, 256GB storage, A17 chip',1099.99,4.80,25,1,'2025-10-14 15:48:36.000000','2025-10-14 15:48:36.000000'),(275,'Samsung Galaxy S25',999.99,60,5,'Flagship smartphone with Dynamic AMOLED 2X',899.99,4.70,35,1,'2025-10-14 15:48:36.000000','2025-10-14 15:48:36.000000'),(276,'OnePlus 12',849.99,70,5,'High-performance Android smartphone with Snapdragon 8 Gen 3',799.99,4.60,20,1,'2025-10-14 15:48:36.000000','2025-10-14 15:48:36.000000'),(277,'Google Pixel 9',949.99,45,5,'Pure Android experience with powerful AI camera',899.99,4.70,22,1,'2025-10-14 15:48:36.000000','2025-10-14 15:48:36.000000'),(278,'Xiaomi 14 Pro',699.99,90,5,'Affordable flagship with AMOLED display and 200MP camera',649.99,4.50,40,1,'2025-10-14 15:48:36.000000','2025-10-14 15:48:36.000000'),(279,'Dell XPS 13',1499.99,40,5,'Slim ultrabook with Intel i7 and 16GB RAM',1399.99,4.80,15,2,'2025-10-14 15:48:36.000000','2025-10-14 15:48:36.000000'),(280,'MacBook Air M2',1249.00,35,5,'Apple M2 chip, 13.6-inch Liquid Retina display',1149.00,4.90,25,2,'2025-10-14 15:48:36.000000','2025-10-14 15:48:36.000000'),(281,'HP Spectre x360',1349.99,30,5,'Convertible touchscreen laptop with 12th Gen Intel i7',1249.99,4.70,18,2,'2025-10-14 15:48:36.000000','2025-10-14 15:48:36.000000'),(282,'Lenovo ThinkPad X1 Carbon',1699.00,25,5,'Business-class laptop, lightweight and durable',1599.00,4.80,10,2,'2025-10-14 15:48:36.000000','2025-10-14 15:48:36.000000'),(283,'ASUS ZenBook 14',1199.00,50,5,'Powerful and portable laptop with OLED display',1099.00,4.60,12,2,'2025-10-14 15:48:36.000000','2025-10-14 15:48:36.000000'),(284,'LG OLED 65 C3',1999.99,20,5,'4K OLED Smart TV with Dolby Vision and HDR10+',1799.99,4.90,8,3,'2025-10-14 15:48:36.000000','2025-10-14 15:48:36.000000'),(285,'Samsung QLED 55 Q80C',1399.99,25,5,'4K QLED Smart TV with Quantum Processor 4K',1299.99,4.80,15,3,'2025-10-14 15:48:36.000000','2025-10-14 15:48:36.000000'),(286,'Sony Bravia 43X80J',799.99,30,5,'43-inch 4K HDR Smart Google TV',749.99,4.70,22,3,'2025-10-14 15:48:36.000000','2025-10-14 15:48:36.000000'),(287,'Mi 4K TV 55',499.99,50,5,'Affordable 4K Smart TV with Dolby Audio',449.99,4.50,40,3,'2025-10-14 15:48:36.000000','2025-10-14 15:48:36.000000'),(288,'TCL 50 QLED C745',699.99,40,5,'Mid-range QLED Smart TV with Dolby Vision IQ',649.99,4.60,32,3,'2025-10-14 15:48:36.000000','2025-10-14 15:48:36.000000'),(289,'Canon EOS R6',2499.00,20,5,'Mirrorless camera, 20MP, 4K 60fps video',2299.00,4.80,12,4,'2025-10-14 15:48:36.000000','2025-10-14 15:48:36.000000'),(290,'Nikon Z6 II',1999.00,15,5,'Full-frame mirrorless camera for professionals',1799.00,4.70,8,4,'2025-10-14 15:48:36.000000','2025-10-14 15:48:36.000000'),(291,'Sony Alpha A7 IV',2499.00,25,5,'33MP mirrorless camera, advanced autofocus',2399.00,4.90,10,4,'2025-10-14 15:48:36.000000','2025-10-14 15:48:36.000000'),(292,'Fujifilm X-T5',1699.00,30,5,'APS-C camera with film simulation modes',1599.00,4.80,20,4,'2025-10-14 15:48:36.000000','2025-10-14 15:48:36.000000'),(293,'Panasonic Lumix G9',1499.00,40,5,'Micro four-thirds camera, 60fps burst shooting',1399.00,4.60,15,4,'2025-10-14 15:48:36.000000','2025-10-14 15:48:36.000000'),(294,'iPhone 15 Pro',1199.99,50,5,'Apple iPhone 15 Pro, 256GB storage, A17 chip',1099.99,4.80,25,1,'2025-10-14 15:52:29.000000','2025-10-14 15:52:29.000000'),(295,'Samsung Galaxy S25',999.99,60,5,'Flagship smartphone with Dynamic AMOLED 2X',899.99,4.70,35,1,'2025-10-14 15:52:29.000000','2025-10-14 15:52:29.000000'),(296,'OnePlus 12',849.99,70,5,'High-performance Android smartphone with Snapdragon 8 Gen 3',799.99,4.60,20,1,'2025-10-14 15:52:29.000000','2025-10-14 15:52:29.000000'),(297,'Google Pixel 9',949.99,45,5,'Pure Android experience with powerful AI camera',899.99,4.70,22,1,'2025-10-14 15:52:29.000000','2025-10-14 15:52:29.000000'),(298,'Xiaomi 14 Pro',699.99,90,5,'Affordable flagship with AMOLED display and 200MP camera',649.99,4.50,40,1,'2025-10-14 15:52:29.000000','2025-10-14 15:52:29.000000'),(299,'Dell XPS 13',1499.99,40,5,'Slim ultrabook with Intel i7 and 16GB RAM',1399.99,4.80,15,2,'2025-10-14 15:52:29.000000','2025-10-14 15:52:29.000000'),(300,'MacBook Air M2',1249.00,35,5,'Apple M2 chip, 13.6-inch Liquid Retina display',1149.00,4.90,25,2,'2025-10-14 15:52:29.000000','2025-10-14 15:52:29.000000'),(301,'HP Spectre x360',1349.99,30,5,'Convertible touchscreen laptop with 12th Gen Intel i7',1249.99,4.70,18,2,'2025-10-14 15:52:29.000000','2025-10-14 15:52:29.000000'),(302,'Lenovo ThinkPad X1 Carbon',1699.00,25,5,'Business-class laptop, lightweight and durable',1599.00,4.80,10,2,'2025-10-14 15:52:29.000000','2025-10-14 15:52:29.000000'),(303,'ASUS ZenBook 14',1199.00,50,5,'Powerful and portable laptop with OLED display',1099.00,4.60,12,2,'2025-10-14 15:52:29.000000','2025-10-14 15:52:29.000000'),(304,'LG OLED 65 C3',1999.99,20,5,'4K OLED Smart TV with Dolby Vision and HDR10+',1799.99,4.90,8,3,'2025-10-14 15:52:29.000000','2025-10-14 15:52:29.000000'),(305,'Samsung QLED 55 Q80C',1399.99,25,5,'4K QLED Smart TV with Quantum Processor 4K',1299.99,4.80,15,3,'2025-10-14 15:52:29.000000','2025-10-14 15:52:29.000000'),(306,'Sony Bravia 43X80J',799.99,30,5,'43-inch 4K HDR Smart Google TV',749.99,4.70,22,3,'2025-10-14 15:52:29.000000','2025-10-14 15:52:29.000000'),(307,'Mi 4K TV 55',499.99,50,5,'Affordable 4K Smart TV with Dolby Audio',449.99,4.50,40,3,'2025-10-14 15:52:29.000000','2025-10-14 15:52:29.000000'),(308,'TCL 50 QLED C745',699.99,40,5,'Mid-range QLED Smart TV with Dolby Vision IQ',649.99,4.60,32,3,'2025-10-14 15:52:29.000000','2025-10-14 15:52:29.000000'),(309,'Canon EOS R6',2499.00,20,5,'Mirrorless camera, 20MP, 4K 60fps video',2299.00,4.80,12,4,'2025-10-14 15:52:29.000000','2025-10-14 15:52:29.000000'),(310,'Nikon Z6 II',1999.00,15,5,'Full-frame mirrorless camera for professionals',1799.00,4.70,8,4,'2025-10-14 15:52:29.000000','2025-10-14 15:52:29.000000'),(311,'Sony Alpha A7 IV',2499.00,25,5,'33MP mirrorless camera, advanced autofocus',2399.00,4.90,10,4,'2025-10-14 15:52:29.000000','2025-10-14 15:52:29.000000'),(312,'Fujifilm X-T5',1699.00,30,5,'APS-C camera with film simulation modes',1599.00,4.80,20,4,'2025-10-14 15:52:29.000000','2025-10-14 15:52:29.000000'),(313,'Panasonic Lumix G9',1499.00,40,5,'Micro four-thirds camera, 60fps burst shooting',1399.00,4.60,15,4,'2025-10-14 15:52:29.000000','2025-10-14 15:52:29.000000'),(314,'Logitech MX Master 3',99.99,120,6,'Advanced wireless mouse with ergonomic design for professionals',89.99,4.80,50,21,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(315,'Razer BlackWidow V3',139.99,80,6,'Mechanical gaming keyboard with customizable RGB lighting',129.99,4.70,40,22,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(316,'Corsair K95 RGB Platinum',199.99,70,6,'High-performance mechanical keyboard with macro keys',179.99,4.70,30,23,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(317,'SteelSeries Arctis 7',149.99,60,6,'Wireless gaming headset with clear audio and comfortable fit',129.99,4.60,25,24,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(318,'HyperX Cloud II',99.99,90,6,'Gaming headset with 7.1 surround sound and memory foam',89.99,4.50,40,25,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(319,'Apple Watch Series 9',399.99,50,6,'Smartwatch with health tracking and cellular connectivity',349.99,4.80,15,26,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(320,'Samsung Galaxy Watch 6',349.99,45,6,'Smartwatch with AMOLED display and fitness tracking',299.99,4.70,18,27,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(321,'Fitbit Charge 6',149.99,60,6,'Activity tracker with heart rate monitoring and sleep tracking',129.99,4.60,30,28,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(322,'Garmin Fenix 7',699.99,25,6,'Rugged GPS smartwatch for outdoor sports and adventure',649.99,4.90,12,29,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(323,'Sony WH-1000XM5',349.99,40,6,'Noise-canceling wireless headphones with premium sound',299.99,4.80,22,30,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(324,'Bose QuietComfort 45',329.99,35,6,'Comfortable noise-canceling headphones with long battery life',299.99,4.70,18,31,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(325,'Canon EOS 90D',1199.00,20,6,'DSLR camera, 32.5MP, 4K video recording',1099.00,4.80,10,32,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(326,'Nikon D7500',999.00,25,6,'DSLR camera with 20.9MP sensor and 4K UHD video',899.00,4.70,15,33,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(327,'DJI Mini 4 Pro',759.99,18,6,'Compact drone with 4K camera and obstacle avoidance',699.99,4.80,12,34,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(328,'DJI Air 3',1199.99,15,6,'High-performance drone with 48MP camera and long battery life',1099.99,4.90,10,35,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(329,'GoPro Hero 12',499.99,40,6,'Action camera with 5.3K video and HyperSmooth stabilization',449.99,4.70,20,36,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(330,'Apple iPad Pro 12.9',1099.99,30,6,'Tablet with M2 chip, Liquid Retina XDR display',999.99,4.90,18,37,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(331,'Samsung Galaxy Tab S9',849.99,25,6,'High-end Android tablet with AMOLED display',799.99,4.80,15,38,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(332,'Microsoft Surface Pro 9',999.99,20,6,'2-in-1 tablet-laptop with Intel i7 and touchscreen',899.99,4.70,12,39,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(333,'Amazon Kindle Oasis',249.99,50,6,'E-reader with 7-inch display and adjustable warm light',199.99,4.60,30,40,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(334,'Samsung Odyssey G9',1499.99,12,6,'49-inch curved gaming monitor with 240Hz refresh rate',1399.99,4.80,8,41,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(335,'LG UltraGear 34GP950',899.99,15,6,'UltraWide gaming monitor, Nano IPS, 160Hz',849.99,4.70,12,42,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(336,'ASUS ROG Swift PG32UQX',2999.99,8,6,'32-inch 4K gaming monitor with HDR1000',2799.99,4.90,5,43,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(337,'BenQ EX3501R',699.99,12,6,'35-inch curved monitor with HDR and adaptive sync',649.99,4.60,10,44,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(338,'Apple AirPods Pro 2',249.99,35,6,'Wireless earbuds with active noise cancellation',199.99,4.80,20,45,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(339,'Sony WF-1000XM5',279.99,30,6,'Premium noise-canceling true wireless earbuds',249.99,4.70,18,46,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(340,'Samsung Galaxy Buds 3',199.99,40,6,'Wireless earbuds with intelligent ANC',179.99,4.60,22,47,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(341,'JBL Charge 6',149.99,50,6,'Portable Bluetooth speaker with deep bass',129.99,4.50,30,48,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(342,'Bose SoundLink Revolve+',49.99,30,6,'360-degree portable Bluetooth speaker with great sound',449.99,4.80,25,49,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(343,'Anker Soundcore Flare 2',99.99,45,6,'Waterproof Bluetooth speaker with LED lights',89.99,4.60,28,50,'2025-10-14 16:08:24.000000','2025-10-14 16:08:24.000000'),(344,'Logitech MX Master 3',99.99,120,6,'Advanced wireless mouse with ergonomic design for professionals',89.99,4.80,50,21,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(345,'Razer BlackWidow V3',139.99,80,6,'Mechanical gaming keyboard with customizable RGB lighting',129.99,4.70,40,22,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(346,'Corsair K95 RGB Platinum',199.99,70,6,'High-performance mechanical keyboard with macro keys',179.99,4.70,30,23,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(347,'SteelSeries Arctis 7',149.99,60,6,'Wireless gaming headset with clear audio and comfortable fit',129.99,4.60,25,24,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(348,'HyperX Cloud II',99.99,90,6,'Gaming headset with 7.1 surround sound and memory foam',89.99,4.50,40,25,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(349,'Apple Watch Series 9',399.99,50,6,'Smartwatch with health tracking and cellular connectivity',349.99,4.80,15,26,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(350,'Samsung Galaxy Watch 6',349.99,45,6,'Smartwatch with AMOLED display and fitness tracking',299.99,4.70,18,27,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(351,'Fitbit Charge 6',149.99,60,6,'Activity tracker with heart rate monitoring and sleep tracking',129.99,4.60,30,28,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(352,'Garmin Fenix 7',699.99,25,6,'Rugged GPS smartwatch for outdoor sports and adventure',649.99,4.90,12,29,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(353,'Sony WH-1000XM5',349.99,40,6,'Noise-canceling wireless headphones with premium sound',299.99,4.80,22,30,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(354,'Bose QuietComfort 45',329.99,35,6,'Comfortable noise-canceling headphones with long battery life',299.99,4.70,18,31,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(355,'Canon EOS 90D',1199.00,20,6,'DSLR camera, 32.5MP, 4K video recording',1099.00,4.80,10,32,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(356,'Nikon D7500',999.00,25,6,'DSLR camera with 20.9MP sensor and 4K UHD video',899.00,4.70,15,33,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(357,'DJI Mini 4 Pro',759.99,18,6,'Compact drone with 4K camera and obstacle avoidance',699.99,4.80,12,34,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(358,'DJI Air 3',1199.99,15,6,'High-performance drone with 48MP camera and long battery life',1099.99,4.90,10,35,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(359,'GoPro Hero 12',499.99,40,6,'Action camera with 5.3K video and HyperSmooth stabilization',449.99,4.70,20,36,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(360,'Apple iPad Pro 12.9',1099.99,30,6,'Tablet with M2 chip, Liquid Retina XDR display',999.99,4.90,18,37,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(361,'Samsung Galaxy Tab S9',849.99,25,6,'High-end Android tablet with AMOLED display',799.99,4.80,15,38,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(362,'Microsoft Surface Pro 9',999.99,20,6,'2-in-1 tablet-laptop with Intel i7 and touchscreen',899.99,4.70,12,39,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(363,'Amazon Kindle Oasis',249.99,50,6,'E-reader with 7-inch display and adjustable warm light',199.99,4.60,30,40,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(364,'Samsung Odyssey G9',1499.99,12,6,'49-inch curved gaming monitor with 240Hz refresh rate',1399.99,4.80,8,41,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(365,'LG UltraGear 34GP950',899.99,15,6,'UltraWide gaming monitor, Nano IPS, 160Hz',849.99,4.70,12,42,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(366,'ASUS ROG Swift PG32UQX',2999.99,8,6,'32-inch 4K gaming monitor with HDR1000',2799.99,4.90,5,43,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(367,'BenQ EX3501R',699.99,12,6,'35-inch curved monitor with HDR and adaptive sync',649.99,4.60,10,44,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(368,'Apple AirPods Pro 2',249.99,35,6,'Wireless earbuds with active noise cancellation',199.99,4.80,20,45,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(369,'Sony WF-1000XM5',279.99,30,6,'Premium noise-canceling true wireless earbuds',249.99,4.70,18,46,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(370,'Samsung Galaxy Buds 3',199.99,40,6,'Wireless earbuds with intelligent ANC',179.99,4.60,22,47,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(371,'JBL Charge 6',149.99,50,6,'Portable Bluetooth speaker with deep bass',129.99,4.50,30,48,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(372,'Bose SoundLink Revolve+',49.99,30,6,'360-degree portable Bluetooth speaker with great sound',449.99,4.80,25,49,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(373,'Anker Soundcore Flare 2',99.99,45,6,'Waterproof Bluetooth speaker with LED lights',89.99,4.60,28,50,'2025-10-14 16:08:28.000000','2025-10-14 16:08:28.000000'),(374,'Apple Mac Mini M2',699.99,20,6,'Compact desktop with M2 chip and fast performance',649.99,4.80,12,51,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(375,'Dell Inspiron 15 5000',749.99,25,6,'Reliable laptop with Intel i5, 16GB RAM, 512GB SSD',699.99,4.60,18,52,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(376,'HP Pavilion Gaming',999.99,20,6,'Gaming laptop with NVIDIA GTX 1660 Ti, Intel i7',949.99,4.70,15,53,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(377,'Lenovo Legion 5',1099.99,18,6,'Powerful gaming laptop with AMD Ryzen 7 and 16GB RAM',1049.99,4.80,10,54,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(378,'ASUS TUF Dash F15',1199.99,22,6,'Thin and light gaming laptop with RTX 3060',1149.99,4.70,12,55,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(379,'Canon EOS R5',3899.00,10,6,'High-end mirrorless camera, 45MP, 8K video recording',3699.00,4.90,8,56,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(380,'Nikon Z9',5499.00,8,6,'Professional full-frame mirrorless camera with 8K video',5299.00,5.00,5,57,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(381,'Sony Alpha 1',6499.00,6,6,'Flagship mirrorless camera, 50MP, 8K video',6299.00,5.00,4,58,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(382,'Fujifilm GFX 100S',9999.00,5,6,'Medium format mirrorless camera, 102MP',9499.00,4.90,3,59,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(383,'Panasonic Lumix S5',1999.00,10,6,'Full-frame mirrorless camera, video-centric',1899.00,4.80,6,60,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(384,'DJI FPV Drone',1299.99,12,6,'Drone with immersive first-person view and 4K video',1199.99,4.70,8,61,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(385,'Parrot Anafi',699.99,18,6,'Compact drone with 4K HDR camera',649.99,4.60,12,62,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(386,'GoPro Max',499.99,20,6,'360-degree action camera with stabilization',449.99,4.70,15,63,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(387,'Apple iPad Air 5',599.99,25,6,'Tablet with M1 chip and Liquid Retina display',549.99,4.80,20,64,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(388,'Samsung Galaxy Tab S8',649.99,20,6,'Android tablet with AMOLED display and stylus support',599.99,4.70,18,65,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(389,'Microsoft Surface Laptop 5',1299.99,18,6,'Sleek laptop with Intel i7 and touchscreen',1249.99,4.80,12,66,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(390,'Apple HomePod Mini',99.99,50,6,'Compact smart speaker with Siri support',89.99,4.70,25,67,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(391,'Amazon Echo Dot 5th Gen',49.99,60,6,'Smart speaker with Alexa voice assistant',39.99,4.60,30,68,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(392,'Google Nest Mini',49.99,55,6,'Compact smart speaker with Google Assistant',39.99,4.60,28,69,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(393,'Sonos One SL',179.99,25,6,'High-quality wireless speaker with multi-room support',159.99,4.80,15,70,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(394,'Samsung Odyssey G7',699.99,15,6,'27-inch curved gaming monitor, 240Hz refresh',649.99,4.70,10,71,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(395,'LG UltraGear 27GL850',449.99,20,6,'27-inch gaming monitor with Nano IPS and 144Hz',399.99,4.60,12,72,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(396,'ASUS ROG Strix XG32VQ',599.99,12,6,'32-inch curved gaming monitor with 165Hz refresh',549.99,4.70,8,73,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(397,'BenQ EX3203R',399.99,20,6,'32-inch curved monitor with HDR10 and FreeSync',359.99,4.50,15,74,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(398,'Apple AirPods Max',549.99,18,6,'Premium over-ear wireless headphones with ANC',499.99,4.90,12,75,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(399,'Sony WH-1000XM5',349.99,20,6,'Noise-canceling over-ear headphones with premium sound',299.99,4.80,15,76,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(400,'Bose QuietComfort 45',329.99,25,6,'Comfortable ANC headphones with long battery',299.99,4.70,18,77,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(401,'JBL Live Pro+',179.99,40,6,'True wireless earbuds with active noise cancellation',159.99,4.60,25,78,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(402,'Samsung Galaxy Buds Live',149.99,35,6,'Ergonomic wireless earbuds with ANC',129.99,4.60,20,79,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(403,'Apple Pencil 2',129.99,25,6,'Precision stylus for iPad with magnetic charging',119.99,4.80,18,80,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(404,'Logitech Crayon',69.99,30,6,'Digital stylus for iPad with tilt support',59.99,4.70,22,81,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(405,'Wacom Intuos Pro',379.99,15,6,'Professional graphic tablet with pen',349.99,4.90,10,82,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(406,'Huion Kamvas 22',399.99,18,6,'Large pen display for digital artists',379.99,4.80,12,83,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(407,'Acer Predator XB273K',699.99,12,6,'27-inch 4K gaming monitor with 144Hz',649.99,4.70,8,84,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(408,'Dell UltraSharp U2723QE',499.99,20,6,'27-inch professional monitor with IPS',449.99,4.70,15,85,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(409,'LG 34WN80C-B',449.99,18,6,'34-inch UltraWide monitor with color accuracy',399.99,4.60,12,86,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(410,'Samsung Odyssey G5',349.99,25,6,'27-inch curved gaming monitor with 144Hz',319.99,4.50,20,87,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(411,'Sony Xperia 1 V',999.99,20,6,'Flagship Android phone with 4K display',949.99,4.70,15,88,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(412,'Google Pixel 8',799.99,30,6,'Pure Android phone with AI camera',749.99,4.60,25,89,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(413,'OnePlus 12 Pro',899.99,25,6,'High-end smartphone with Snapdragon 8 Gen 3',849.99,4.70,18,90,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(414,'Samsung Galaxy Z Flip 5',1099.99,15,6,'Foldable smartphone with dynamic AMOLED display',1049.99,4.80,10,91,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(415,'Motorola Edge 40',699.99,28,6,'Sleek smartphone with curved OLED display',649.99,4.50,22,92,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(416,'Sony Xperia 10 V',499.99,35,6,'Mid-range smartphone with triple camera',449.99,4.40,28,93,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(417,'ASUS ROG Phone 7',899.99,18,6,'Gaming phone with Snapdragon 8 Gen 3 and 165Hz display',849.99,4.70,12,94,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(418,'Black Shark 6',749.99,20,6,'Gaming-focused smartphone with high refresh rate',699.99,4.60,18,95,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(419,'Realme GT 3',499.99,30,6,'Affordable flagship with AMOLED display',449.99,4.50,25,96,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(420,'Vivo X90 Pro',899.99,20,6,'Premium smartphone with gimbal camera',849.99,4.70,15,97,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(421,'Oppo Find X6 Pro',999.99,18,6,'High-end Android phone with AMOLED display',949.99,4.80,12,98,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(422,'Xiaomi Mix Fold 3',1299.99,12,6,'Foldable Android phone with large AMOLED display',1249.99,4.70,8,99,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000'),(423,'Huawei Mate X3',1399.99,10,6,'Premium foldable smartphone with 5G support',1349.99,4.60,6,100,'2025-10-14 16:12:08.000000','2025-10-14 16:12:08.000000');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_management_cartitems`
--

DROP TABLE IF EXISTS `shop_management_cartitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_management_cartitems` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `quantity` int NOT NULL,
  `product_id` bigint NOT NULL,
  `cart_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_management_cartitems_product_id_24e10436_fk_products_id` (`product_id`),
  KEY `shop_management_cart_cart_id_66d521bf_fk_shop_mana` (`cart_id`),
  CONSTRAINT `shop_management_cart_cart_id_66d521bf_fk_shop_mana` FOREIGN KEY (`cart_id`) REFERENCES `shop_management_carts` (`id`),
  CONSTRAINT `shop_management_cartitems_product_id_24e10436_fk_products_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_management_cartitems`
--

LOCK TABLES `shop_management_cartitems` WRITE;
/*!40000 ALTER TABLE `shop_management_cartitems` DISABLE KEYS */;
/*!40000 ALTER TABLE `shop_management_cartitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_management_carts`
--

DROP TABLE IF EXISTS `shop_management_carts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_management_carts` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `customer_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_management_carts_customer_id_0d2b62bc_fk_customers_id` (`customer_id`),
  CONSTRAINT `shop_management_carts_customer_id_0d2b62bc_fk_customers_id` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_management_carts`
--

LOCK TABLES `shop_management_carts` WRITE;
/*!40000 ALTER TABLE `shop_management_carts` DISABLE KEYS */;
/*!40000 ALTER TABLE `shop_management_carts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_management_categories`
--

DROP TABLE IF EXISTS `shop_management_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_management_categories` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_management_categories`
--

LOCK TABLES `shop_management_categories` WRITE;
/*!40000 ALTER TABLE `shop_management_categories` DISABLE KEYS */;
INSERT INTO `shop_management_categories` VALUES (1,'Electronics','Electronic gadgets and devices','2025-10-14 15:29:44.000000'),(2,'Home Appliances','Household electrical appliances','2025-10-14 15:29:44.000000'),(3,'Fashion','Clothing and fashion accessories','2025-10-14 15:29:44.000000'),(4,'Footwear','Shoes and sandals for all','2025-10-14 15:29:44.000000'),(5,'Beauty & Personal Care','Cosmetics and skincare','2025-10-14 15:29:44.000000'),(6,'Sports & Fitness','Equipment and sportswear','2025-10-14 15:29:44.000000'),(7,'Books','Books and magazines','2025-10-14 15:29:44.000000'),(8,'Furniture','Home and office furniture','2025-10-14 15:29:44.000000'),(9,'Toys','Kids toys and collectibles','2025-10-14 15:29:44.000000'),(10,'Groceries','Daily essentials and food items','2025-10-14 15:29:44.000000'),(11,'Mobile Accessories','Chargers, cables, and covers','2025-10-14 15:29:44.000000'),(12,'Computer Accessories','Peripherals and components','2025-10-14 15:29:44.000000'),(13,'Kitchenware','Cookware and utensils','2025-10-14 15:29:44.000000'),(14,'Stationery','Office and school supplies','2025-10-14 15:29:44.000000'),(15,'Garden Supplies','Gardening tools and plants','2025-10-14 15:29:44.000000'),(16,'Pet Supplies','Food and accessories for pets','2025-10-14 15:29:44.000000'),(17,'Jewellery','Gold and artificial jewellery','2025-10-14 15:29:44.000000'),(18,'Automotive','Car and bike accessories','2025-10-14 15:29:44.000000'),(19,'Music Instruments','Guitars, keyboards, and more','2025-10-14 15:29:44.000000'),(20,'Art & Craft','Drawing and craft materials','2025-10-14 15:29:44.000000'),(21,'Lighting','LEDs and lamps','2025-10-14 15:29:44.000000'),(22,'Smart Devices','Smart home gadgets','2025-10-14 15:29:44.000000'),(23,'Health & Wellness','Health monitoring devices','2025-10-14 15:29:44.000000'),(24,'Watches','Smart and analog watches','2025-10-14 15:29:44.000000'),(25,'Bags & Luggage','Travel bags and wallets','2025-10-14 15:29:44.000000'),(26,'Baby Products','Products for infants','2025-10-14 15:29:44.000000'),(27,'Gaming','Consoles and accessories','2025-10-14 15:29:44.000000'),(28,'Food & Beverages','Packaged and gourmet foods','2025-10-14 15:29:44.000000'),(29,'Outdoor Equipment','Camping and trekking gear','2025-10-14 15:29:44.000000'),(30,'Home Decor','Decorative home items','2025-10-14 15:29:44.000000'),(31,'Building Materials','Tools and construction items','2025-10-14 15:29:44.000000'),(32,'Pharmacy','Medicines and supplements','2025-10-14 15:29:44.000000'),(33,'Photography','Cameras and tripods','2025-10-14 15:29:44.000000'),(34,'Perfumes','Fragrances for men and women','2025-10-14 15:29:44.000000'),(35,'Beverages','Soft drinks and juices','2025-10-14 15:29:44.000000'),(36,'Home Cleaning','Detergents and cleaning tools','2025-10-14 15:29:44.000000'),(37,'Security','Locks and cameras','2025-10-14 15:29:44.000000'),(38,'Travel Accessories','Travel gear and kits','2025-10-14 15:29:44.000000'),(39,'Craft Supplies','DIY kits and art materials','2025-10-14 15:29:44.000000'),(40,'Gardening','Seeds and fertilizers','2025-10-14 15:29:44.000000'),(41,'Office Equipment','Printers and scanners','2025-10-14 15:29:44.000000'),(42,'Hardware Tools','Screwdrivers, drills, etc.','2025-10-14 15:29:44.000000'),(43,'Musical Accessories','Speakers and mics','2025-10-14 15:29:44.000000'),(44,'Home Storage','Organizers and racks','2025-10-14 15:29:44.000000'),(45,'Fitness Wear','Gym clothes and shoes','2025-10-14 15:29:44.000000'),(46,'Cleaning Equipment','Vacuums and mops','2025-10-14 15:29:44.000000'),(47,'Party Supplies','Decorations and balloons','2025-10-14 15:29:44.000000'),(48,'Bath & Shower','Soaps and shampoos','2025-10-14 15:29:44.000000'),(49,'Skincare','Facewash and creams','2025-10-14 15:29:44.000000'),(50,'Haircare','Shampoo and oils','2025-10-14 15:29:44.000000'),(51,'Home Improvement','DIY home projects','2025-10-14 15:29:44.000000'),(52,'Computer Software','Operating systems and tools','2025-10-14 15:29:44.000000'),(53,'Networking Devices','Wi-Fi routers and cables','2025-10-14 15:29:44.000000'),(54,'Mobile Phones','Android and iPhones','2025-10-14 15:29:44.000000'),(55,'Wearables','Smart bands and watches','2025-10-14 15:29:44.000000'),(56,'Televisions','Smart TVs','2025-10-14 15:29:44.000000'),(57,'Audio Systems','Speakers and soundbars','2025-10-14 15:29:44.000000'),(58,'Cameras & Drones','DSLRs and drones','2025-10-14 15:29:44.000000'),(59,'Smart Home Devices','Assistants and hubs','2025-10-14 15:29:44.000000'),(60,'Kitchen Appliances','Blenders and mixers','2025-10-14 15:29:44.000000'),(61,'Cookware','Nonstick pans and pots','2025-10-14 15:29:44.000000'),(62,'Tableware','Dishes and cups','2025-10-14 15:29:44.000000'),(63,'Storage Boxes','Containers and racks','2025-10-14 15:29:44.000000'),(64,'Bedding','Bedsheets and blankets','2025-10-14 15:29:44.000000'),(65,'Curtains','Window and door curtains','2025-10-14 15:29:44.000000'),(66,'Car Accessories','Seat covers and mats','2025-10-14 15:29:44.000000'),(67,'Bike Accessories','Helmets and oils','2025-10-14 15:29:44.000000'),(68,'Electricals','Switches and wires','2025-10-14 15:29:44.000000'),(69,'Tools & Equipment','Industrial tools','2025-10-14 15:29:44.000000'),(70,'Safety Products','Helmets and gloves','2025-10-14 15:29:44.000000'),(71,'Stationery Supplies','Pens and notebooks','2025-10-14 15:29:44.000000'),(72,'Baby Toys','Educational toys','2025-10-14 15:29:44.000000'),(73,'Kids Wear','Clothes for children','2025-10-14 15:29:44.000000'),(74,'Men’s Wear','Formal and casual wear','2025-10-14 15:29:44.000000'),(75,'Women’s Wear','Ethnic and western wear','2025-10-14 15:29:44.000000'),(76,'Seasonal','Festive and occasion items','2025-10-14 15:29:44.000000'),(77,'Gift Items','Gifts and hampers','2025-10-14 15:29:44.000000'),(78,'Luxury Products','Premium goods','2025-10-14 15:29:44.000000'),(79,'Accessories','Belts, caps, etc.','2025-10-14 15:29:44.000000'),(80,'Sunglasses','Shades and eyewear','2025-10-14 15:29:44.000000'),(81,'Watches & Jewelry','Branded watches','2025-10-14 15:29:44.000000'),(82,'Ethnic Wear','Traditional clothes','2025-10-14 15:29:44.000000'),(83,'Laptops','Portable computers','2025-10-14 15:29:44.000000'),(84,'Tablets','Portable smart devices','2025-10-14 15:29:44.000000'),(85,'Software','Applications and licenses','2025-10-14 15:29:44.000000'),(86,'Hardware','Computer parts','2025-10-14 15:29:44.000000'),(87,'Networking','Switches and routers','2025-10-14 15:29:44.000000'),(88,'Cables','Chargers and connectors','2025-10-14 15:29:44.000000'),(89,'Batteries','Power cells','2025-10-14 15:29:44.000000'),(90,'Printers','Ink and laser printers','2025-10-14 15:29:44.000000'),(91,'Scanners','Image and doc scanners','2025-10-14 15:29:44.000000'),(92,'Office Supplies','Desks and chairs','2025-10-14 15:29:44.000000'),(93,'Kitchen Storage','Jars and boxes','2025-10-14 15:29:44.000000'),(94,'Lighting Fixtures','Ceiling and wall lights','2025-10-14 15:29:44.000000'),(95,'Home Safety','Fire alarms','2025-10-14 15:29:44.000000'),(96,'Electronics Repair Tools','Multimeters and kits','2025-10-14 15:29:44.000000'),(97,'Craft Tools','Paints and brushes','2025-10-14 15:29:44.000000'),(98,'Outdoor Furniture','Garden chairs','2025-10-14 15:29:44.000000'),(99,'Camping Gear','Tents and sleeping bags','2025-10-14 15:29:44.000000'),(100,'Adventure Sports','Climbing and biking gear','2025-10-14 15:29:44.000000'),(101,'Virtual Reality','VR headsets','2025-10-14 15:29:44.000000'),(102,'3D Printing','Printers and materials','2025-10-14 15:29:44.000000'),(103,'AI Devices','Smart assistants','2025-10-14 15:29:44.000000'),(104,'Drones','Quadcopters','2025-10-14 15:29:44.000000');
/*!40000 ALTER TABLE `shop_management_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_management_customsession`
--

DROP TABLE IF EXISTS `shop_management_customsession`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_management_customsession` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `session_id` varchar(64) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `expires_at` datetime(6) NOT NULL,
  `customer_id` bigint DEFAULT NULL,
  `shopkeeper_id` bigint DEFAULT NULL,
  `last_activity` datetime(6) NOT NULL,
  `user_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_id` (`session_id`),
  KEY `shop_management_cust_customer_id_cd8ad6b4_fk_customers` (`customer_id`),
  KEY `shop_management_cust_shopkeeper_id_65370539_fk_shopkeepe` (`shopkeeper_id`),
  KEY `shop_management_customsession_user_id_97ac0976_fk_auth_user_id` (`user_id`),
  CONSTRAINT `shop_management_cust_customer_id_cd8ad6b4_fk_customers` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `shop_management_cust_shopkeeper_id_65370539_fk_shopkeepe` FOREIGN KEY (`shopkeeper_id`) REFERENCES `shopkeepers` (`id`),
  CONSTRAINT `shop_management_customsession_user_id_97ac0976_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_management_customsession`
--

LOCK TABLES `shop_management_customsession` WRITE;
/*!40000 ALTER TABLE `shop_management_customsession` DISABLE KEYS */;
INSERT INTO `shop_management_customsession` VALUES (108,'1e499774-8f46-4390-b3de-41b062f9b08c','2025-10-15 04:36:38.039505','2025-10-15 08:36:38.038415',NULL,5,'2025-10-15 04:36:38.039610',NULL);
/*!40000 ALTER TABLE `shop_management_customsession` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_management_notifications`
--

DROP TABLE IF EXISTS `shop_management_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_management_notifications` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `message` longtext NOT NULL,
  `read` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `customer_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_management_noti_customer_id_7977d210_fk_customers` (`customer_id`),
  CONSTRAINT `shop_management_noti_customer_id_7977d210_fk_customers` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_management_notifications`
--

LOCK TABLES `shop_management_notifications` WRITE;
/*!40000 ALTER TABLE `shop_management_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `shop_management_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_management_promotions`
--

DROP TABLE IF EXISTS `shop_management_promotions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_management_promotions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `discount_percentage` int NOT NULL,
  `start_date` datetime(6) NOT NULL,
  `end_date` datetime(6) NOT NULL,
  `product_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_management_promotions_product_id_fabc8e63_fk_products_id` (`product_id`),
  CONSTRAINT `shop_management_promotions_product_id_fabc8e63_fk_products_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_management_promotions`
--

LOCK TABLES `shop_management_promotions` WRITE;
/*!40000 ALTER TABLE `shop_management_promotions` DISABLE KEYS */;
/*!40000 ALTER TABLE `shop_management_promotions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_management_reviews`
--

DROP TABLE IF EXISTS `shop_management_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_management_reviews` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `rating` decimal(3,2) NOT NULL,
  `comment` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `customer_id` bigint NOT NULL,
  `product_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `shop_management_reviews_product_id_customer_id_49c88a31_uniq` (`product_id`,`customer_id`),
  KEY `shop_management_reviews_customer_id_97158bbf_fk_customers_id` (`customer_id`),
  CONSTRAINT `shop_management_reviews_customer_id_97158bbf_fk_customers_id` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `shop_management_reviews_product_id_7ef455ee_fk_products_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_management_reviews`
--

LOCK TABLES `shop_management_reviews` WRITE;
/*!40000 ALTER TABLE `shop_management_reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `shop_management_reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_management_wishlists`
--

DROP TABLE IF EXISTS `shop_management_wishlists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_management_wishlists` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `added_at` datetime(6) NOT NULL,
  `customer_id` bigint NOT NULL,
  `product_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `shop_management_wishlists_customer_id_product_id_5ed0d0ea_uniq` (`customer_id`,`product_id`),
  KEY `shop_management_wishlists_product_id_3ae615bd_fk_products_id` (`product_id`),
  CONSTRAINT `shop_management_wishlists_customer_id_b874e39e_fk_customers_id` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `shop_management_wishlists_product_id_3ae615bd_fk_products_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_management_wishlists`
--

LOCK TABLES `shop_management_wishlists` WRITE;
/*!40000 ALTER TABLE `shop_management_wishlists` DISABLE KEYS */;
/*!40000 ALTER TABLE `shop_management_wishlists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopkeepers`
--

DROP TABLE IF EXISTS `shopkeepers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shopkeepers` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` varchar(20) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `address` longtext,
  `deleted_at` datetime(6) DEFAULT NULL,
  `is_verified` tinyint(1) NOT NULL,
  `phone_number` bigint NOT NULL,
  `rating` double NOT NULL,
  `shop_name` varchar(100) DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `password` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `shopkeepers_username_6c4d0739` (`username`),
  KEY `shopkeepers_usernam_2540e7_idx` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopkeepers`
--

LOCK TABLES `shopkeepers` WRITE;
/*!40000 ALTER TABLE `shopkeepers` DISABLE KEYS */;
INSERT INTO `shopkeepers` VALUES (1,'rakesh','rakesh@example.com','shopkeeper','2025-10-06 12:42:06.823387',NULL,NULL,0,7417176963,0,NULL,'2025-10-10 12:15:32.680463',NULL),(2,'mani','mani@example.com','shopkeeper','2025-10-06 13:07:13.671594',NULL,NULL,0,7417176963,0,NULL,'2025-10-10 12:15:32.680463',NULL),(3,'anurag_shop','anurag@example.com','shopkeeper','2025-10-13 06:29:29.425919','123 Main Street, Bangalore, India',NULL,0,6662735337,0,'Anurag Electronics','2025-10-13 06:29:29.426480',NULL),(5,'shopkeeper1','shopkeeper1@example.com','shopkeeper','2025-10-14 07:09:34.302422','123 Main Street, City, Country',NULL,1,9000000000,4.5,'Tech World','2025-10-14 07:09:34.309919','pbkdf2_sha256$1000000$Job05HF9UMo7Fu2NC4kdh8$2HBWY0lIAE7+z8d9hHWdPr/hejDSttZh7BsfDjumz88='),(6,'shopkeeper2','shopkeeper2@example.com','shopkeeper','2025-10-14 10:24:19.563368','123 Main Street, City, Country',NULL,1,9000000002,4.7,'Quality Products Shop','2025-10-14 10:24:19.578375','pbkdf2_sha256$1000000$XOGIsfd2WXrlYas1WAviPv$jFxlkYOigEkhvhoYSAj0ueStLCnoE5/V8/gGl7twqn0=');
/*!40000 ALTER TABLE `shopkeepers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-15 11:48:02
