from django.apps import AppConfig

class ShopManagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'shop_management'
    